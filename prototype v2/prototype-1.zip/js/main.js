/*
stage 1: 41400141-44
stage 2: 41400221-26
stage 3: 41400311-15
stage 4: 41400401-06
    */

matchSelect();

$('#timeline').slider().on('change',function(value){
    sliderValue = $('#timeline').data('slider').getValue();
    opId=opList[sliderValue-1];
    d3.select("#team2-img").attr("src","img/"+opId+".png");
    d3.select("#team2-title").text(refIdToName[opId]).style("color",teamColors[sliderValue-1]);
    matchSelect();
});

function matchSelect(){
    var loopNum;
    switch (sliderValue){
        case 1:
            loopNum=4;
            gameIdBase=41400140;
            break;
        case 2:
            loopNum=6;
            gameIdBase=41400220;
            break;
        case 3:
            loopNum=5;
            gameIdBase=41400310;
            break;
        case 4:
            loopNum=6;
            gameIdBase=41400400;
            break;
    }

    $(".match-button").map(function(){
        //console.log(($(this).attr("class")));
        if($(this).is(".disabled")){
            $(this).removeClass("disabled")
        }
        if (this.id.replace("match","")>loopNum){
            $(this).addClass("disabled");
        }
    });
    $("#match1").trigger("click");
}

$(".match-button").click(function(){
    matchSeriesId=parseInt(this.id.replace("match",""));
    setMatchId();
});


function setMatchId(){
    matchId="00"+(matchSeriesId+gameIdBase).toString();
    //console.log(matchId);
    opId=opList[sliderValue-1];
//    d3.select("#team2-img").attr("src","img/"+opId+".png");
//    console.log("img/"+opId+".png");
    statNames[1]=refIdToName[opId];
    updateTeamVisualiteam_zation(matchId);
    updateStatBarchart();
}

//load stat bar chart data
d3.csv("data/gamelog.csv",function(error,csv){
    csv.forEach(function(d){
        if (error) throw error;
        // Convert numeric values to 'numbers'
        d.fgm_x=+d.fgm_x;
        d.reb_x=+d.reb_x;
        d.ast_x=+d.ast_x;
        d.stl_x=+d.stl_x;
        d.blk_x=+d.blk_x;
        d.tov_x=+d.tov_x;
        d.pts_x=+d.pts_x;
        d.fgm_y=+d.fgm_y;
        d.reb_y=+d.reb_y;
        d.ast_y=+d.ast_y;
        d.stl_y=+d.stl_y;
        d.blk_y=+d.blk_y;
        d.tov_y=+d.tov_y;
        d.pts_y=+d.pts_y;
    });
    allStat=csv;

    updateStatBarchart()
});

//team-shooting-chart
d3.csv("data/team_shots.csv", function(error, csv) {
    csv.forEach(function(d) {

        // Convert numeric values to 'numbers'
        d.loc_x = +d.loc_x * 10;
        d.loc_y = (+d.loc_y-5.25)*10;
        d.period = +d.period;
        d.shot_made_numeric = +d.shot_made_numeric;

    });
    // Store csv data in global variable
    team_data = csv;

    updateTeamVisualiteam_zation(matchId);
});

